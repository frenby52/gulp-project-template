//= ../../../../node_modules/slick-carousel/slick/slick.js

$(".slider").slick({

});
